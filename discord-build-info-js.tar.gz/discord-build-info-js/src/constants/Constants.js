module.exports = {
    release_channels: ['canary', 'stable', 'ptb']
}